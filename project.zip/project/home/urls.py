from django.urls import path
from .views import *

urlpatterns = [
    path('',index,name='index'),
    path("sheet",sheet,name="sheet"),
    path('attendence/',attendance, name='attendence'),
    path("add_student/",add_student,name="add_student")

]
