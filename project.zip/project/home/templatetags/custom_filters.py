from django import template

register = template.Library()

@register.filter
def get_item(value, arg):
    """Custom filter to access dictionary keys."""
    return value.get(arg, None)
