from django.contrib import admin
from django.utils.html import format_html
from datetime import date
from .models import Student,AttendanceRecord,Stack


class StudentAdmin(admin.ModelAdmin):
    list_display = ['full_name', 'batch', 'phone', 'email', 'display_status', 'highlight_long_tenure']
    # list_editable = ['present']
    list_filter = ['batch', 'present']
    search_fields = ['first_name', 'last_name']

    def display_status(self, obj):
        """Custom display for status."""
        if obj.present == 'Present':
            return "🟢 Present"
        elif obj.present == 'Absent':
            return "🔴 Absent"
        elif obj.present == 'Interview':
            return "🔵 Interview"
        return "Unknown"
    
    display_status.short_description = "Status"

    def full_name(self, obj):
        """Combine first and last name."""
        return f"{obj.first_name} {obj.last_name}"
    
    full_name.short_description = "Full Name"

    def highlight_long_tenure(self, obj):
        if obj.join_date and (date.today() - obj.join_date).days > 90:

            formatted_date = obj.join_date.strftime('%b. %d, %Y')
            return format_html(
                '<span style="background-color: yellow; color: black;">{}</span>',
                formatted_date
            )
        return obj.join_date.strftime('%b. %d, %Y') if obj.join_date else "Unknown"

    highlight_long_tenure.short_description = "Join Date"


admin.site.register(Student, StudentAdmin)
admin.site.register(AttendanceRecord)
admin.site.register(Stack)